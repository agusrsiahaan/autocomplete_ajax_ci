Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/how-to-autocomplete-textbox-in-codeigniter-with-jquery-ui/

Instructions - 

* base_url
Rename the folder and edit $config['base_url'] in application/config/config.php

* Database connection
Update database connection in application/config/database.php
